
public class MultipleCatch {
	
	public static void main(String[] args) {
		try {
			int a = args.length;
			System.out.println("a: " + a);
			int b = 42/a;
			int c[] = {1};
			c[5] = 10;
		}
		catch(ArithmeticException e) {
			System.out.println("Div by 0" + e);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Array index oob: " + e);
		}
		System.out.println("After try catch blocks.");
	}
}
